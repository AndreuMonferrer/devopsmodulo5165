import os

from flask import Flask, jsonify

app = Flask(__name__)
CITAS = [{"id": 1, "paciente": "Ana", "dia": "2027-01-15"}]


@app.route("/salud")
def salud():
    return jsonify(estado="ok", entorno=os.getenv("ENTORNO", "local"))


@app.route("/citas")
def citas():
    return jsonify(CITAS)
