# cita-previa-app

API mínima de cita previa usada en la unidad 5 del módulo 5165 (Metodología DevOps).
Todos los datos son de prueba.

| Ruta | Respuesta |
|---|---|
| `/salud` | Estado de la aplicación y entorno en el que se ejecuta |
| `/citas` | Lista de citas |

Ejecutar en local:

    python3 -m venv .venv
    . .venv/bin/activate
    pip install -r requirements-dev.txt
    flask --app app run

Pruebas: `pytest`. Imagen: `docker build -t cita-previa-app .`
