import pytest

from app import app


@pytest.fixture
def cliente():
    app.config["TESTING"] = True
    return app.test_client()


def test_salud(cliente):
    r = cliente.get("/salud")
    assert r.status_code == 200
    assert r.get_json()["estado"] == "ok"


def test_citas_devuelve_lista(cliente):
    r = cliente.get("/citas")
    assert r.status_code == 200
    assert isinstance(r.get_json(), list)


@pytest.mark.parametrize("ruta", ["/no-existe", "/citas/extra"])
def test_rutas_inexistentes(cliente, ruta):
    assert cliente.get(ruta).status_code == 404
